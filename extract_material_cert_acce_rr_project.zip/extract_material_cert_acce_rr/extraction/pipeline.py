"""Per-file orchestration for the RR material cert OCR pipeline."""

import threading
from pathlib import Path
from urllib.parse import quote

import pandas as pd

from . import config
from .ocr import read_relevant_pages
from .parsing import (
    canonicalize_lots,
    check_averages,
    extract_lot_info,
    extract_spools,
    extract_tack,
    extract_tg,
    lot_from_filename,
    page_lot,
)


def file_to_sharepoint_url(file, pdf_path, sharepoint_url):
    """
    Build the SharePoint URL for a PDF from its local path under pdf_path.

    Assumes pdf_path is a local OneDrive shortcut to the SharePoint folder at
    sharepoint_url -- the two must point to the same folder level so the
    relative paths line up.
    """
    rel_path = Path(file).resolve().relative_to(Path(pdf_path).resolve())
    rel_url = quote(str(rel_path).replace('\\', '/'))
    return f'{sharepoint_url}/{rel_url}'


def _lot_record():
    return {
        'part_number': None,
        'mfg_date': None,
        'spools': [],
        'tg': [],
        'tack': [],
        'spool_averages': None,
    }


def _dedupe(items):
    """Drop exact repeats (a page can appear twice in a PDF), keeping order."""
    seen, out = set(), []
    for item in items:
        key = repr(item)
        if key not in seen:
            seen.add(key)
            out.append(item)
    return out


def _process_file(file, pdf_path, sharepoint_url, log):
    """Two-pass read of one cert PDF. Returns a DataFrame of per-spool rows.

    A PDF can hold more than one lot, so everything is grouped by lot first.
    """
    log(f'\n  Processing {Path(file).name} ...')

    pages = read_relevant_pages(file, config.LOW_DPI)
    if not any({'tg', 'tack', 'spool'} & kinds for kinds, _ in pages.values()):
        retry = config.LOW_DPI + 50
        log(f'    Nothing relevant at {config.LOW_DPI} DPI, retrying at {retry} DPI...')
        pages = read_relevant_pages(file, retry)
        if not pages:
            log(f'    Still none; skipping {Path(file).name}.')
            return pd.DataFrame()

    # Resolve each page's lot first so an OCR slip in one page header (e.g. a
    # doubled M) cannot split a lot in two. Spool tables run over several pages.
    page_lots = {
        pn: page_lot(pages[pn][1], pages[pn][0], Path(file).name) for pn in sorted(pages)
    }
    canon = canonicalize_lots([l for l in page_lots.values() if l])
    for seen, fixed in canon.items():
        if seen != fixed:
            log(f'    Lot "{seen}" read as "{fixed}".')

    lots: dict[str, dict] = {}
    for pn in sorted(pages):
        kinds, text = pages[pn]
        lot = canon.get(page_lots[pn])
        if lot is None:
            log(f'    Page {pn}: could not determine lot; skipped.')
            continue
        rec = lots.setdefault(lot, _lot_record())

        if 'lot_info' in kinds:
            info = extract_lot_info(text)
            rec['part_number'] = rec['part_number'] or info['part_number']
            rec['mfg_date'] = rec['mfg_date'] or info['mfg_date']
        if 'tg' in kinds:
            rec['tg'].extend(extract_tg(text))
        if 'tack' in kinds:
            rec['tack'].extend(extract_tack(text))
        if 'spool' in kinds:
            rows, averages = extract_spools(text, lot)
            rec['spools'].extend(rows)
            if averages:
                rec['spool_averages'] = averages

    out = []
    for lot, rec in sorted(lots.items()):
        spools = _dedupe(rec['spools'])
        tg = [v for _, v in _dedupe(rec['tg'])]
        tack = [avg for _, avg in _dedupe(rec['tack']) if avg is not None]
        avg_ok = check_averages(spools, rec['spool_averages'])

        lot_fields = {
            'part_number': rec['part_number'],
            'lot_number': lot,
            'mfg_date': rec['mfg_date'],
        }
        for i, v in enumerate(tg, 1):
            lot_fields[f'tg_{i}'] = v
        lot_fields['tg_avg'] = round(sum(tg) / len(tg), 1) if tg else None
        for i, v in enumerate(tack, 1):
            lot_fields[f'tack_{i}'] = v
        lot_fields['tack_avg'] = round(sum(tack) / len(tack), 3) if tack else None

        if not spools:
            spools = [
                {'spool_number': None, 'rc': None, 'paw': None, 'note': 'no spool table found'}
            ]

        for s in spools:
            notes = [s['note']] if s['note'] else []
            if avg_ok is False:
                notes.append('lot RC/PAW average does not match printed averages')
            if s['spool_number'] and (s['rc'] is None or s['paw'] is None):
                notes.append('RC or PAW not read')
            out.append({
                **lot_fields,
                'spool_number': s['spool_number'],
                'rc': s['rc'],
                'paw': s['paw'],
                'needs_review': bool(notes),
                'notes': '; '.join(notes) or None,
                'pdf_path': str(Path(file).resolve()),
                **(
                    {'pdf_url': file_to_sharepoint_url(file, pdf_path, sharepoint_url)}
                    if sharepoint_url
                    else {}
                ),
            })

    df = pd.DataFrame(out)
    if not df.empty:
        log(f'    Extracted {len(df)} spool record(s) from {df["lot_number"].nunique()} lot(s).')
    return df


_print_lock = threading.Lock()


def process_file(file, pdf_path, sharepoint_url=''):
    """Thread-safe wrapper: buffers this file's messages and prints them together,
    so output from parallel files does not interleave."""
    msgs = []
    try:
        return _process_file(file, pdf_path, sharepoint_url, msgs.append)
    finally:
        with _print_lock:
            print('\n'.join(msgs))
