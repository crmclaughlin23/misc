# Cost and calculations for equipment runs

from math import pi
import pandas as pd
import numpy as np
import local_constants.constants as constants

def compute_n2_cost(pressure, df_group, equip_name, reference_df, solve_vdw_moles):
    """Compute nitrogen usage (SCF) and costs ($/SCF) per run"""
    n2_used = n2_cost = 0
    
    if not pressure or 'Press' not in df_group.columns and 'AirTC' not in df_group.columns:
        return 0.0, 0.0, 0.0

    try:
        shape = reference_df.loc[reference_df['equipment'] == equip_name, 'shape'].iloc[0]
        if shape == 'cylinder':
            radius = reference_df.loc[reference_df['equipment'] == equip_name, 'width'].iloc[0] / 2
            length = reference_df.loc[reference_df['equipment'] == equip_name, 'length'].iloc[0]
            V = ((pi * radius**2 * length) * (pi * 4/3 * radius**3)) * 0.85
        else:
            L = reference_df[reference_df['equipment'] == equip_name]['length'].iloc[0]
            W = reference_df[reference_df['equipment'] == equip_name]['width'].iloc[0]
            H = reference_df[reference_df['equipment'] == equip_name]['height'].iloc[0]
            V = L * W * H
            
        df_group['psia'] = df_group['Press'] + 14.7
        df_group['AirTC_K'] = (df_group['AirTC'] - 32) * 5/9 + 273.15
        p_end = df_group['psia'].max() / constants.PSI_TO_ATM
        if p_end < 2:
            p_end = 0
        t_end = df_group.loc[df_group['psia'].idxmax(), 'AirTC_K']
        
        V_L = V * constants.FT3_TO_L
        n2_moles = solve_vdw_moles(p_end, V_L, t_end, constants.A, constants.B, constants.R)
        
        if n2_moles > 0:
            n2_grams = n2_moles * constants.N2_MOLAR_MASS
            n2_liters = n2_grams / constants.N2_DENSITY
            n2_ft3 = n2_liters * constants.FT3_TO_L
            n2_used = n2_ft3
            n2_cost = round(n2_used * constants.NITROGEN_RATE, 2)
            
        return n2_used, n2_cost, V
    except Exception as e:
        print(f'Error computing N2 cost: {e}')
        return 0.0, 0.0, 0.0
    
def compute_electricy_and_gas_seg_cost(df_seg, equip_ref, equip_kw_cap, duration):
    """Compute per-segment electricity (kWh) and gas (SCF) usage and costs ($/kWh and $/SCF) per run"""
    results = []
    for index, row in equip_ref.iterrows():
        input_name = row['input_name']
        if input_name not in df_seg.columns:
            continue
        
        input_type = row['input_type']
        kw_value = row['kw_value']
        analog_divisor = row.get('analog_divisor', 1)
        
        electricity_used = gas_used = 0
        if input_type == 'Digital':
            time_on_min = (df_seg[input_name] == -1).sum()
            electricity_used = (time_on_min / 60) * kw_value
        elif input_type == 'Analog':
            values = pd.to_numeric(df_seg[input_name], errors='coerce')
            percent = values / analog_divisor
            kw_series = percent * kw_value
            electricity_used = kw_series.sum() / 60
        elif input_type == 'Gas':
            values = pd.to_numeric(df_seg[input_name], errors='coerce')
            gas_used = values.sum() / 60
            
        electricity_cost = electricity_used * constants.ELECTRICITY_RATE
        electricity_fle = electricity_used / equip_kw_cap
        avg_electricity_draw = electricity_used / (duration / 60)
        electricity_utilization = avg_electricity_draw / equip_kw_cap
        gas_cost = gas_used * constants.GAS_RATE
        gas_fle = gas_used / (duration / 60)
        
        results.append({
            'input_name': input_name,
            'input_type': input_type,
            'kw_capacity': equip_kw_cap,
            'electricity_used': round(electricity_used, 2),
            'electricity_cost': round(electricity_cost, 2),
            'electricity_fle': round(electricity_fle, 2),
            'electricity_utilization': round(electricity_utilization, 2),
            'gas_used': round(gas_used, 2),
            'gas_cost': round(gas_cost, 2),
            'gas_fle': round(gas_fle, 2)
        })    
    return results