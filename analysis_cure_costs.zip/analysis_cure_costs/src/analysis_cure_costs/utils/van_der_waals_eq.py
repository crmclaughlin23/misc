# This function uses the Van der Waals equation to calculate moles used

from scipy.optimize import fsolve

def solve_vdw_moles(P, V, T, a=1.352, b=0.0387, R=0.08206):
    """
    Solves for n (moles) using the Van der Waals equation:
    (P + a * n^2 / V^2) * (V - n * b) = nRT
    P: pressure (atm)
    V: volume (liters)
    T: temperature (Kelvin)
    Returns: moles (n)
    """
    def vdw_eq(n):
        return (P + a * (n ** 2) / V ** 2) * (V - n * b) - n * R * T

    n_guess = P * V / (R * T)  # Ideal gas guess
    n_solution, = fsolve(vdw_eq, n_guess)
    return max(n_solution, 0)  # Clamp negative solutions to 0