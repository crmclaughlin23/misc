# Run Cost Analysis Calculation Pipeline
# Calculating electricity, gas, and nitrogen costs per run

# --- Third Party Packages --- #
import re
import numpy as np
import pandas as pd
from sqlalchemy import text

# --- Shared Packages --- #
from shared_utils.sqlserver import get_engine, read_table, replace_table
from shared_config.sqlserver import PYRO_SERVER, PROD_SERVER, PYRO_DATABASE

# --- Project Packages --- #
import analysis_cure_costs.config as config
import analysis_cure_costs.constants as constants
from analysis_cure_costs.utils.van_der_waals_eq import solve_vdw_moles
from analysis_cure_costs.utils.transform_data import clean_data

prod_engine = get_engine(PROD_SERVER, PYRO_DATABASE)
runs_data = read_table(prod_engine, 'EquipUsage_Runs')

def filter_pressure_spikes(press_series):
    values = press_series.to_numpy()
    mask = np.ones(len(values), dtype=bool)
    last_valid = values[0]
    
    for i in range(1, len(values)):
        curr = values[i]
        if abs(last_valid) < 1.0:
            last_valid = curr
            continue
        pct_change = abs((curr - last_valid) / last_valid)
        threshold = 9.0 if last_valid < 10 else 4.0
        if pct_change < threshold:
            last_valid = curr
        else:
            mask[i] = False
            
    return mask


def run_pipeline():
    print('\nStarting Cure Cost Analysis Pipeline...')

    pyro_server = PYRO_SERVER
    reference_df = pd.read_excel(config.EQUIP_INPUTS_PATH, sheet_name='RunCostInfo')
    pressure_ref_df = pd.read_excel(config.EQUIP_INPUTS_PATH, sheet_name='EquipInfo')
    ref_df = pd.merge(
        reference_df,
        pressure_ref_df,
        left_on='equipment',
        right_on='equip_name',
        how='left',
    )

    results = []

    pyro_engine = get_engine(pyro_server, 'master')

    with pyro_engine.connect() as conn:
        result = conn.execute(text("""
            SELECT name
            FROM SYS.DATABASES
            WHERE name LIKE 'CPC_%'
                AND name NOT LIKE 'CPC_Staging';                         
        """))
        databases = [row[0] for row in result]

    for db_name in databases:
        for name in config.DATABASE_NAMES:
            if db_name != name:
                continue

            print(f'  Extracting data from {db_name}...')
            db_engine = get_engine(pyro_server, db_name)

            with db_engine.connect() as db_conn:
                preview_query = f"""
                    SELECT TOP(1) Datafile
                    FROM {db_name}.dbo.Runs
                """
                row = db_conn.execute(text(preview_query)).mappings().fetchone()
                if not row:
                    print(f'    Skipping {db_name} (do data found)...')
                    continue

                equip_from_datafile = row['Datafile']
                equip_name = re.split(r'[-_]', equip_from_datafile)[0].upper()

                press_value = ref_df.loc[ref_df['equip_name'] == equip_name, 'pressure']
                pressure = press_value.iloc[0] if not press_value.empty else None
                equip_power = ref_df.loc[
                    ref_df['equip_name'] == equip_name, 'equip_power'
                ]

                ref_df['equipment'] = ref_df['equipment'].str.upper()
                equip_ref = ref_df[ref_df['equipment'] == equip_name]

                if equip_ref.empty:
                    print(f'    Skipping {db_name} (no reference data found)...')
                    continue

                equip_kw_cap = equip_ref['kw_value'].sum()

                column_query = f"""
                    SELECT column_name
                    FROM {db_name}.information_schema.columns
                    WHERE table_name = 'RunData'
                """
                result = db_conn.execute(text(column_query))
                available_columns = {row[0] for row in result}

                columns_to_pull = [
                    col
                    for col in equip_ref['input_name'].tolist()
                    if col in available_columns
                ]
                if not columns_to_pull:
                    print(f'    Skipping {db_name} (no matching columns found)...')
                    continue

                # Define the additional columns to include in the common_query
                if pressure == 'yes':
                    additional_columns = 'rd.Press, rd.AirTC'
                elif (pressure == 'yes') and (equip_power == 'gas'):
                    additional_columns = 'rd.Press, rd.AirTC, rd.BURNERGASFLOW'
                elif (pressure == 'no') and (equip_power == 'gas'):
                    additional_columns = 'rd.BURNERGASFLOW'
                else:
                    additional_columns = ''

                # Define the common parts of the query
                common_query = f"""
                    SELECT r.Datafile, r.StartTime, r.Recipe, r.Duration, rd.RunElapsedTime, 
                        {', '.join(additional_columns.split(', '))}, 
                        {', '.join(columns_to_pull)}, rd.Seg
                    FROM {db_name}.dbo.RunData AS rd
                    INNER JOIN {db_name}.dbo.Runs AS r
                        ON rd.RunID = r.RunID
                """

                # Construct the final query
                runs_data_query = f'{common_query}'

                try:
                    result = db_conn.execute(text(runs_data_query))
                    run_df = pd.DataFrame(result.fetchall(), columns=result.keys())
                    run_df['Datafile'] = run_df['Datafile'].astype(str)
                    run_df['Recipe'] = run_df['Recipe'].astype(str)
                    run_df['StartTime'] = pd.to_datetime(run_df['StartTime'])
                    run_df['Date'] = run_df['StartTime'].dt.date

                    run_df['ElapsedMinute'] = run_df['RunElapsedTime'].astype(int)
                    run_df = run_df.drop_duplicates(
                        subset=['Datafile', 'ElapsedMinute'], keep='first'
                    )
                except Exception as e:
                    print(f'    Query failed for {db_name}: {e}')
                    continue

                if run_df.empty:
                    print(f'    Skipping {db_name} (no rows in RunData)...')
                    continue

                grouped = run_df.groupby(['Datafile'])

                for cure, df_group in grouped:
                    recipe = df_group['Recipe'].iloc[0]
                    date = df_group['Date'].iloc[0]
                    duration = df_group['Duration'].iloc[0]
                    datafile = cure
                    # press_on_min = (df_group['POUT'] > 50).sum()

                    # press_max = (
                    #     df_group['Press'].max() if 'Press' in df_group.columns else None
                    # )
                    # press_cost = 0

                    if (
                        pressure
                        and 'Press' in df_group.columns
                        and 'AirTC' in df_group.columns
                    ):
                        shape = ref_df.loc[
                            ref_df['equipment'] == equip_name, 'shape'
                        ].iloc[0]
                        if shape == 'cylinder':
                            radius = (
                                ref_df.loc[
                                    ref_df['equipment'] == equip_name, 'width'
                                ].iloc[0]
                                / 2
                            )
                            length = ref_df.loc[
                                ref_df['equipment'] == equip_name, 'length'
                            ].iloc[0]
                            V = (
                                (3.1416 * (radius**2) * length)
                                + (3.1416 * 4 / 3 * (radius**3))
                            ) * 0.85
                        elif shape == 'box':
                            length = ref_df.loc[
                                ref_df['equipment'] == equip_name, 'length'
                            ].iloc[0]
                            width = ref_df.loc[
                                ref_df['equipment'] == equip_name, 'width'
                            ].iloc[0]
                            height = ref_df.loc[
                                ref_df['equipment'] == equip_name, 'height'
                            ].iloc[0]
                            V = length * width * height
                            
#----------------------------------------------------------------------------------------------------------------------------------------------
# SCRIPTING THAT CALCULATES N2 MOLES OVER ENTIRETY OF CURE (NOT JUST BASED ON MAX PRESSURE READING)
                        df_group = df_group.sort_values(by=['ElapsedMinute']).copy()
                        df_group['psia'] = df_group['Press'] + 14.7
                        df_group['AirTC_K'] = (df_group['AirTC'] - 32) * 5/9 + 273.15    # convert F to K
                        
                        # Iterative spike filter - each row compared to last accepted value
                        # START TEST
                        mask = filter_pressure_spikes(df_group['Press'])
                        df_group = df_group[mask]
                        # END TEST

                        V_L = V * constants.FT3_TO_L
                        p_series = (df_group['psia'] / constants.PSI_TO_ATM).to_numpy()
                        t_series = df_group['AirTC_K'].to_numpy()
                        
                        n_series = np.array([solve_vdw_moles(p, V_L, t) for p, t in zip(p_series, t_series)])
                        dn = np.diff(n_series, prepend=n_series[0])
                        
                        p_atm = 14.7 / constants.PSI_TO_ATM
                        n_first = n_series[0]
                        n_ambient = solve_vdw_moles(p_atm, V_L, t_series[0])
                        baseline = max(0.0, n_first - n_ambient)
                        
                        n2_moles = baseline + dn[1:][dn[1:] > 0].sum()
#----------------------------------------------------------------------------------------------------------------------------------------------    

                        # df_group['psia'] = df_group['Press'] + 14.7
                        # df_group['AirTC_K'] = (
                        #     df_group['AirTC'] - 32
                        # ) * 5 / 9 + 273.15  # convert F to K

                        # p_end = (
                        #     df_group['psia'].max() / constants.PSI_TO_ATM
                        # )  # convert psi to atm
                        # if p_end < 2:
                        #     p_end = 0
                        # t_end = df_group.loc[df_group['psia'].idxmax(), 'AirTC_K']

                        # V_L = V * constants.FT3_TO_L

                        # n2_moles = solve_vdw_moles(p_end, V_L, t_end)

                        if n2_moles > 0:
                            n2_grams = n2_moles * constants.N2_MOLAR_MASS
                            n2_liters = n2_grams / constants.N2_DENSITY
                            n2_ft3 = n2_liters / constants.FT3_TO_L
                            n2_used = n2_ft3  # n2_used is in SCF units
                            n2_fle = n2_used / (duration / 60)
                            n2_cost = round(n2_used * config.NITROGEN_RATE, 2)

                        else:
                            n2_used = 0
                            n2_fle = 0
                            n2_cost = 0

                    else:
                        n2_used = 0
                        n2_fle = 0
                        n2_cost = 0

                    for seg, df_seg in df_group.groupby('Seg'):
                        datafile = df_seg['Datafile'].iloc[0]
                        seg_duration = (
                            df_seg['RunElapsedTime'].max()
                            - df_seg['RunElapsedTime'].min()
                        )

                        gas_used = 0

                        for _, row in equip_ref.iterrows():
                            input_name = row['input_name']
                            if input_name not in df_seg.columns:
                                continue

                            input_type = row['input_type']
                            kw_value = row['kw_value']
                            analog_divisor = row.get('analog_divisor', 1)

                            if input_type == 'Digital':
                                time_on_min = (df_seg[input_name] == -1).sum()
                                kwh_used = (time_on_min / 60) * kw_value
                            elif input_type == 'Analog':
                                values = pd.to_numeric(
                                    df_seg[input_name], errors='coerce'
                                )
                                percent = values / analog_divisor
                                kw_series = percent * kw_value
                                kwh_used = (kw_series.sum()) / 60
                            elif input_type == 'Gas':
                                values = pd.to_numeric(
                                    df_seg[input_name], errors='coerce'
                                )
                                scf_series = values
                                gas_used = (
                                    scf_series.sum()
                                ) / 60  # gas_used is in SCF units

                            kwh_cost = kwh_used * config.ELECTRICITY_RATE
                            gas_fle = gas_used / (duration / 60)
                            gas_cost = gas_used * config.GAS_RATE
                            kwh_fle = kwh_used / equip_kw_cap
                            seg_minutes = seg_duration if seg_duration > 0 else 1
                            avg_kwh_draw = kwh_used / (seg_minutes / 60)
                            kwh_utilization = avg_kwh_draw / equip_kw_cap

                            results.append(
                                {
                                    'equip_name': equip_name,
                                    'volume_ft3': round(V, 0),
                                    'datafile': datafile,
                                    'recipe': recipe,
                                    'seg': seg,
                                    'date': date,
                                    'duration': duration,
                                    'seg_duration': seg_duration,
                                    'input_name': input_name,
                                    'input_type': input_type,
                                    'kw_capacity': equip_kw_cap,
                                    'kwh_used': round(kwh_used, 2),
                                    'kwh_cost': round(kwh_cost, 2),
                                    'kwh_fle': round(kwh_fle, 2),
                                    'kwh_utilization': round(kwh_utilization, 2),
                                    'n2_used': round(n2_used, 2),
                                    'n2_fle': round(n2_fle, 2),
                                    'n2_cost': round(n2_cost, 2),
                                    'gas_used': round(gas_used, 2),
                                    'gas_fle': round(gas_fle, 2),
                                    'gas_cost': round(gas_cost, 2),
                                }
                            )

    results_df = pd.DataFrame(results)
    results_df = results_df.round(2)
    results_df = clean_data(results_df)

    print('\nData extraction complete. /nBeginning data analysis...')

    print('  Generating Segmented Run Cost Data...')
    per_cure_seg_results = (
        results_df.groupby(['equip_name', 'datafile', 'recipe', 'seg', 'duration'])
        .agg(
            volume_ft3=('volume_ft3', 'mean'),
            kwh_used=('kwh_used', 'sum'),
            kwh_cost=('kwh_cost', 'sum'),
            kw_capacity=('kw_capacity', 'mean'),
            kwh_fle=('kwh_fle', 'sum'),
            kwh_utilization=('kwh_utilization', 'sum'),
            n2_used=('n2_used', 'mean'),
            n2_fle=('n2_fle', 'mean'),
            n2_cost=('n2_cost', 'mean'),
            gas_used=('gas_used', 'mean'),
            gas_fle=('gas_fle', 'mean'),
            gas_cost=('gas_cost', 'sum'),
        )
        .reset_index()
    )
    per_cure_seg_results['recipe'] = per_cure_seg_results['recipe'].str.strip()
    per_cure_seg_results['kwh_cost_per_hr'] = (
        per_cure_seg_results['kwh_cost'] / per_cure_seg_results['duration'] * 60
    ).round(2)
    per_cure_seg_results['gas_cost_per_hr'] = (
        per_cure_seg_results['gas_cost'] / per_cure_seg_results['duration'] * 60
    ).round(2)

    combined_per_cure_seg_results = pd.merge(
        per_cure_seg_results[
            [
                'volume_ft3',
                'datafile',
                'seg',
                'kwh_used',
                'kwh_cost',
                'kwh_cost_per_hr',
                'kw_capacity',
                'kwh_fle',
                'kwh_utilization',
                'n2_used',
                'n2_fle',
                'n2_cost',
                'gas_used',
                'gas_fle',
                'gas_cost',
                'gas_cost_per_hr',
            ]
        ],
        runs_data[
            [
                'Datafile',
                'Equipment',
                'Site',
                'Recipe',
                'RecipeRevision',
                'Program',
                'Date',
                'StartTime',
                'EndTime',
                'Duration',
                'Avg_Duration',
                'Operator',
                'Max_Air',
                'Max_Part',
                'Max_Seg',
                'PurgeTime',
                'PurgeEndTime',
                'Aborted',
                'PartCount',
            ]
        ],
        left_on='datafile',
        right_on='Datafile',
        how='right',
    )
    combined_per_cure_seg_results['kwh_cost_per_part'] = (
        combined_per_cure_seg_results['kwh_cost']
        / combined_per_cure_seg_results['PartCount']
    ).round(2)
    combined_per_cure_seg_results['n2_cost_per_part'] = (
        combined_per_cure_seg_results['n2_cost']
        / combined_per_cure_seg_results['PartCount']
    ).round(2)
    combined_per_cure_seg_results['gas_cost_per_part'] = (
        combined_per_cure_seg_results['gas_cost']
        / combined_per_cure_seg_results['PartCount']
    ).round(2)
    combined_per_cure_seg_results['total_cost'] = (
        combined_per_cure_seg_results['kwh_cost']
        + combined_per_cure_seg_results['n2_cost']
        + combined_per_cure_seg_results['gas_cost']
    ).round(2)
    combined_per_cure_seg_results['total_cost_per_part'] = (
        combined_per_cure_seg_results['total_cost']
        / combined_per_cure_seg_results['PartCount']
    ).round(2)
    combined_per_cure_seg_results['total_cost_per_ft3'] = (
        combined_per_cure_seg_results['total_cost']
        / combined_per_cure_seg_results['volume_ft3']
    )
    combined_per_cure_seg_results['total_cost_per_part_per_ft3'] = (
        combined_per_cure_seg_results['total_cost_per_part']
        / combined_per_cure_seg_results['volume_ft3']
    )
    combined_per_cure_seg_results['total_cost_per_hr'] = combined_per_cure_seg_results[
        'total_cost'
    ] / (combined_per_cure_seg_results['Duration'] / 60)
    combined_per_cure_seg_results = combined_per_cure_seg_results.dropna(
        subset=['datafile']
    )

    segmented_run_cost_data = combined_per_cure_seg_results[
        [
            'Datafile',
            'Equipment',
            'Site',
            'Recipe',
            'RecipeRevision',
            'Program',
            'Date',
            'StartTime',
            'EndTime',
            'Duration',
            'Avg_Duration',
            'Operator',
            'Max_Air',
            'Max_Part',
            'Max_Seg',
            'PurgeTime',
            'PurgeEndTime',
            'Aborted',
            'PartCount',
            'seg',
            'kwh_used',
            'kwh_cost',
            'kwh_cost_per_hr',
            'kwh_cost_per_part',
            'kw_capacity',
            'kwh_fle',
            'kwh_utilization',
            'n2_used',
            'n2_cost',
            'n2_cost_per_part',
            'n2_fle',
            'gas_used',
            'gas_cost',
            'gas_cost_per_hr',
            'gas_cost_per_part',
            'gas_fle',
            'total_cost',
            'total_cost_per_part',
            'total_cost_per_ft3',
            'total_cost_per_part_per_ft3',
            'total_cost_per_hr',
        ]
    ]

    segmented_run_cost_data.loc[:, 'RecipeRevision'] = segmented_run_cost_data[
        'RecipeRevision'
    ].replace('', '-')

    print('  Generating Run Cost Data...')
    per_cure_results = (
        per_cure_seg_results.groupby(['equip_name', 'datafile', 'recipe', 'duration'])
        .agg(
            volume_ft3=('volume_ft3', 'first'),
            kwh_used=('kwh_used', 'sum'),
            kwh_cost=('kwh_cost', 'sum'),
            kw_capacity=('kw_capacity', 'mean'),
            kwh_fle=('kwh_fle', 'sum'),
            kwh_utilization=('kwh_utilization', 'mean'),
            n2_used=('n2_used', 'mean'),
            n2_fle=('n2_fle', 'mean'),
            n2_cost=('n2_cost', 'mean'),
            gas_used=('gas_used', 'mean'),
            gas_fle=('gas_fle', 'mean'),
            gas_cost=('gas_cost', 'sum'),
        )
        .round(2)
        .reset_index()
    )
    per_cure_results['recipe'] = per_cure_results['recipe'].str.strip()
    per_cure_results['kwh_cost_per_hr'] = (
        per_cure_results['kwh_cost'] / per_cure_results['duration'] * 60
    ).round(2)
    per_cure_results['gas_cost_per_hr'] = (
        per_cure_results['gas_cost'] / per_cure_results['duration'] * 60
    ).round(2)

    combined_per_cure_results = pd.merge(
        per_cure_results[
            [
                'volume_ft3',
                'datafile',
                'kwh_used',
                'kwh_cost',
                'kwh_cost_per_hr',
                'kw_capacity',
                'kwh_fle',
                'kwh_utilization',
                'n2_used',
                'n2_fle',
                'n2_cost',
                'gas_used',
                'gas_fle',
                'gas_cost',
                'gas_cost_per_hr',
            ]
        ],
        runs_data[
            [
                'Datafile',
                'Equipment',
                'Site',
                'Recipe',
                'RecipeRevision',
                'Program',
                'Date',
                'StartTime',
                'EndTime',
                'Duration',
                'Avg_Duration',
                'Operator',
                'Max_Air',
                'Max_Part',
                'Max_Seg',
                'PurgeTime',
                'PurgeEndTime',
                'Aborted',
                'PartCount',
            ]
        ],
        left_on='datafile',
        right_on='Datafile',
        how='right',
    )

    combined_per_cure_results['kwh_cost_per_part'] = (
        combined_per_cure_results['kwh_cost'] / combined_per_cure_results['PartCount']
    ).round(2)
    combined_per_cure_results['n2_cost_per_part'] = (
        combined_per_cure_results['n2_cost'] / combined_per_cure_results['PartCount']
    ).round(2)
    combined_per_cure_results['gas_cost_per_part'] = (
        combined_per_cure_results['gas_cost'] / combined_per_cure_results['PartCount']
    ).round(2)
    combined_per_cure_results['total_cost'] = (
        combined_per_cure_results['kwh_cost']
        + combined_per_cure_results['n2_cost']
        + combined_per_cure_results['gas_cost']
    ).round(2)
    combined_per_cure_results['total_cost_per_part'] = (
        combined_per_cure_results['total_cost'] / combined_per_cure_results['PartCount']
    ).round(2)
    combined_per_cure_results['total_cost_per_ft3'] = (
        combined_per_cure_results['total_cost']
        / combined_per_cure_results['volume_ft3']
    )
    combined_per_cure_results['total_cost_per_part_per_ft3'] = (
        combined_per_cure_results['total_cost_per_part']
        / combined_per_cure_results['volume_ft3']
    )
    combined_per_cure_results['total_cost_per_hr'] = combined_per_cure_results[
        'total_cost'
    ] / (combined_per_cure_results['Duration'] / 60)
    combined_per_cure_results = combined_per_cure_results.dropna(subset=['datafile'])

    run_cost_data = combined_per_cure_results[
        [
            'Datafile',
            'Equipment',
            'Site',
            'Recipe',
            'RecipeRevision',
            'Program',
            'Date',
            'StartTime',
            'EndTime',
            'Duration',
            'Avg_Duration',
            'Operator',
            'Max_Air',
            'Max_Part',
            'Max_Seg',
            'PurgeTime',
            'PurgeEndTime',
            'Aborted',
            'PartCount',
            'kwh_used',
            'kwh_cost',
            'kwh_cost_per_hr',
            'kwh_cost_per_part',
            'kw_capacity',
            'kwh_fle',
            'kwh_utilization',
            'n2_used',
            'n2_cost',
            'n2_cost_per_part',
            'n2_fle',
            'gas_used',
            'gas_cost',
            'gas_cost_per_hr',
            'gas_cost_per_part',
            'gas_fle',
            'total_cost',
            'total_cost_per_part',
            'total_cost_per_ft3',
            'total_cost_per_part_per_ft3',
            'total_cost_per_hr',
        ]
    ]

    run_cost_data.loc[:, 'RecipeRevision'] = run_cost_data['RecipeRevision'].replace(
        '', '-'
    )

    segmented_run_cost_data = segmented_run_cost_data.replace([np.inf, -np.inf], np.nan)
    segmented_run_cost_data = segmented_run_cost_data.dropna(how='any')
    segmented_run_cost_data = segmented_run_cost_data.round(2)
    run_cost_data = run_cost_data.replace([np.inf, -np.inf], np.nan)
    run_cost_data = run_cost_data.dropna(how='any')
    run_cost_data = run_cost_data.round(2)
    print('\nData analysis complete...')

    print(rf'\nWriting data to {PROD_SERVER}\{PYRO_DATABASE}...')
    replace_table(segmented_run_cost_data, 'EquipEfficiency_CostPerRunSeg', prod_engine)
    replace_table(run_cost_data, 'EquipEfficiency_CostPerRun', prod_engine)
