# Project-specific configuration settings

import os
from pathlib import Path

# Set default server environment
ENV = 'production'

# Set path to global reference file
BASE_DIR = Path(__file__).resolve().parents[2]
EQUIP_INPUTS_PATH = BASE_DIR / 'references' / 'EquipInputs.xlsx'

# Set databases to analyze
DATABASE_NAMES = [
    'CPC_AC1', 'CPC_AC2', 'CPC_AC3', 'CPC_AC4', 'CPC_AC6',
    'CPC_AC9', 'CPC_AC10',
    'CPC_AC11', 'CPC_AC12', # 'CPC_AC16',
    'CPC_AC13', 'CPC_AC15',
    'CPC_CAC1', 'CPC_CAC2', 'CPC_CAC3', 'CPC_CAC4', 'CPC_CAC5'
]

# Electricity
ELECTRICITY_RATE = 0.12 # $/kWh

# Gas
GAS_RATE = 0.0062 # $/SCF

# Nitrogen
NITROGEN_RATE = 0.003109 # $/SCF