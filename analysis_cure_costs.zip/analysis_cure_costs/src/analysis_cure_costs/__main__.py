from .pipeline import run_pipeline

def main():
    print('Running Cure Cost Analysis pipeline...')
    run_pipeline()
    
if __name__ == "__main__":
    main()