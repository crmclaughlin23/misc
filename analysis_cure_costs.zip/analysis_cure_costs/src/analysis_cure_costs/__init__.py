from .pipeline import run_pipeline

def main_cli():
    print('Running Cure Cost Analysis pipeline...')
    run_pipeline()