"""Runs the RR (MSRR4040) material certification OCR extraction."""

import argparse

from extraction import config as extract_config
from extraction.main import run as run_extraction
from extraction.main import write_output


def main():
    parser = argparse.ArgumentParser(
        description='Run RR material cert OCR extraction and write the results to Excel.'
    )
    parser.add_argument(
        '--rerun-all',
        action='store_true',
        help='Re-run all PDFs instead of only new ones.',
    )
    args = parser.parse_args()

    df_all = run_extraction(
        extract_config.get_pdf_path(),
        extract_config.SHAREPOINT_URL,
        extract_config.OUTPUT_PATH,
        args.rerun_all,
    )

    if df_all is None or df_all.empty:
        print('No new material cert files to analyze: skipping write')
    else:
        write_output(df_all, extract_config.OUTPUT_PATH, args.rerun_all)

    print('\nDone.')


if __name__ == '__main__':
    main()
