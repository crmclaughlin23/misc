"""Runs the RR (MSRR4040) material certification OCR extraction and loads it to SQL Server."""

from extraction import config as extract_config
from extraction.main import run as run_extraction
from shared_config.sqlserver import PROD_SERVER, PYRO_DATABASE
from shared_utils.sqlserver import get_engine, replace_table


def main():
    prod_engine = get_engine(PROD_SERVER, PYRO_DATABASE)

    df_all = run_extraction(
        extract_config.get_pdf_path(), extract_config.SHAREPOINT_URL
    )

    if df_all is None or df_all.empty:
        print('No data extracted: skipping DB write')
    else:
        replace_table(
            df_all, table_name=extract_config.TABLE_NAME, engine_name=prod_engine
        )

    print('\nDone.')


if __name__ == '__main__':
    main()
