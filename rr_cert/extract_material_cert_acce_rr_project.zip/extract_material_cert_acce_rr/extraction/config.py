"""Configuration constants for the RR (MSRR4040) material certification OCR pipeline"""

import os

PROJECT_PATH = r'C:\analytics-work\development\extract_material_cert_acce_rr'

PROD_PDF_PATH = rf'{PROJECT_PATH}\data'

TABLE_NAME = 'material_cert_acce_rr'

# Leave blank if the PDFs have no SharePoint home; pdf_url is then omitted.
SHAREPOINT_URL = ''

# Env overrides exist so the pipeline can run off the Windows box (e.g. CI / Linux).
POPPLER_PATH = os.environ.get('POPPLER_PATH', r'C:\Program Files\poppler\Library\bin')
TESSERACT_PATH = os.environ.get(
    'TESSERACT_PATH', r'C:\Program Files\Tesseract-OCR\tesseract.exe'
)

LOW_DPI = 160
HIGH_DPI = 275
OCR_CONFIG = r'--oem 3 --psm 6'
MAX_WORKERS_PDF = 4
MAX_WORKERS_PAGE = 1

# Pages with fewer characters than this in the PDF text layer are treated as scans.
MIN_TEXT_CHARS = 80

# Plausible value ranges. Parsing is by range, not column position, because
# OCR inserts stray characters and shifts columns.
RC_RANGE = (30, 50)
AWT_RANGE = (270, 300)
PAW_RANGE = (440, 490)
TG_RANGE = (150, 400)
AVG_TOLERANCE = 1.0  # allowed gap between computed and printed spool averages


def get_pdf_path(test: bool = False) -> str:
    """Return the PDF root folder."""
    return PROD_PDF_PATH
