"""Text parsers for RR (MSRR4040) material cert pages. Pure functions, no I/O."""

import re
from datetime import datetime

from . import config

MONTHS = (
    'January|February|March|April|May|June|July|August|September|'
    'October|November|December'
)

# Lot numbers look like 92M0114922. OCR may put a space inside (92M01 14922) or
# read a zero as the letter O.
LOT_RE = re.compile(r'\d{2}M[0O\d](?:\s?\d){6}')
PART_RE = re.compile(r'(MSRR\d{4}-[A-Z0-9]+)')
MFG_DATE_RE = re.compile(
    rf'Date\s*of\s*Manufacture\s*:?\s*(\d{{1,2}}\s+(?:{MONTHS})\s+\d{{4}})', re.I
)
TG_LABEL_RE = re.compile(r't[g9q]\s*by\s*dma\s*in', re.I)
TG_VALUE_RE = re.compile(r'(?<!\d)(\d{3}\.\d)')
TACK_LINE_RE = re.compile(r'tack\s*force\s*\(', re.I)
TACK_AVG_RE = re.compile(r'tack\s*force\s*avg\W+\w{2,4}\W+(\d+[.,]\d+)', re.I)
TACK_READING_RE = re.compile(r'(\d+[.,]\d{3})')
PANEL_RE = re.compile(r'(\d{3})/(\d{3})')
AVG_NUM_RE = re.compile(r'\d{2,3}\.\d')
SPOOL_LOT_HEADER_RE = re.compile(r'lot\s*averages\s*report\s*for\s*lot\s*:?\s*(\S+)', re.I)


def clean_lot(raw):
    """Normalize an OCR'd lot number: drop spaces, letter O -> zero."""
    s = re.sub(r'\s+', '', raw).upper()
    return s[:3] + s[3:].replace('O', '0')


def find_lot(text):
    """First lot number found in a block of text, or None."""
    m = LOT_RE.search(text)
    return clean_lot(m.group(0)) if m else None


def lot_from_filename(filename):
    return find_lot(filename)


def classify_page_text(text):
    """Return the set of record kinds a page holds: lot_info, spool, tg, tack."""
    low = re.sub(r'\s+', ' ', (text or '').lower())
    kinds = set()
    if 'date of manufacture' in low and 'lot no' in low:
        kinds.add('lot_info')
    if 'lot averages report' in low:
        kinds.add('spool')
    if TG_LABEL_RE.search(low):
        kinds.add('tg')
    if 'tack force' in low:
        kinds.add('tack')
    return kinds


def page_lot(text, kinds, filename=''):
    """Lot number a page belongs to (a PDF can hold several lots)."""
    m = SPOOL_LOT_HEADER_RE.search(text)
    if m and 'spool' in kinds:
        lot = find_lot(m.group(1)) or clean_lot(m.group(1))
        if lot:
            return lot
    m = re.search(r'lot\s*(?:no|number)\s*:?\s*(' + LOT_RE.pattern + ')', text, re.I)
    if m:
        return clean_lot(m.group(1))
    return find_lot(text) or lot_from_filename(filename)


def extract_lot_info(text):
    """part_number and mfg_date from a certificate-of-analysis cover page."""
    part = PART_RE.search(text)
    date = MFG_DATE_RE.search(text)
    mfg_date = None
    if date:
        mfg_date = datetime.strptime(re.sub(r'\s+', ' ', date.group(1)).title(), '%d %B %Y')
    return {'part_number': part.group(1) if part else None, 'mfg_date': mfg_date}


def _to_float(s):
    try:
        return float(s.replace(',', '.'))
    except ValueError:
        return None


def _in(v, rng):
    return v is not None and rng[0] <= v <= rng[1]


def extract_tg(text):
    """Per-panel Tg by DMA (deg C). Returns [(panel, value), ...] in page order."""
    out = []
    for line in text.splitlines():
        m = TG_LABEL_RE.search(line)
        if not m or re.search(r'\bavg\b', line, re.I):
            continue
        val = next(
            (float(v) for v in TG_VALUE_RE.findall(line[m.start():]) if _in(float(v), config.TG_RANGE)),
            None,
        )
        if val is None:
            continue
        panel = PANEL_RE.search(line)
        out.append((panel.group(2) if panel else None, val))
    return out


def extract_tack(text):
    """
    ASTM D8336 Nottingham tack, per panel. Returns [(readings, avg), ...].

    A readings line ('Tack Force (lbf) a - b - c') is followed by its
    'Tack Force Avg (lbf)' line. The printed average is used; if it is missing
    the mean of the readings is used instead.
    """
    out, readings = [], None
    for line in text.splitlines():
        avg = TACK_AVG_RE.search(line)
        if avg:
            val = _to_float(avg.group(1))
            if readings and val is None:
                val = round(sum(readings) / len(readings), 3)
            out.append((readings or [], val))
            readings = None
            continue
        if TACK_LINE_RE.search(line):
            after = line[TACK_LINE_RE.search(line).end():]
            readings = [_to_float(v) for v in TACK_READING_RE.findall(after)]
            readings = [v for v in readings if v is not None]
    return out


def repair_paw(tokens):
    """PAW is garbled by an inserted or substituted digit (4162, 160 -> 46x).
    Only used when no token is already in range. Returns (value, note) or (None, None)."""
    for tok in tokens:
        if not tok.isdigit():
            continue
        if len(tok) == 4:  # extra digit inserted
            fixes = {int(tok[:i] + tok[i + 1:]) for i in range(4)}
            fixes = {f for f in fixes if _in(f, config.PAW_RANGE)}
            if len(fixes) == 1:
                return fixes.pop(), f'OCR read {tok}: dropped extra digit'
        if len(tok) == 3 and tok[0] in '1l7':  # leading 4 misread
            fixed = int('4' + tok[1:])
            if _in(fixed, config.PAW_RANGE):
                return fixed, f'OCR read {tok}: first digit set to 4'
    return None, None


def _split_glued(tokens):
    """Some scans glue PAW and RC into one token ('45939' -> PAW 459, RC 39)."""
    for tok in tokens:
        if re.fullmatch(r'\d{5}', tok):
            paw, rc = int(tok[:3]), int(tok[3:])
            if _in(paw, config.PAW_RANGE) and _in(rc, config.RC_RANGE):
                return rc, paw
    return None, None


def extract_spools(text, lot):
    """
    Spool rows from a 'Lot Averages Report' page.
    Returns (rows, printed_averages) where rows are dicts of spool_number, rc, paw, note
    and printed_averages is {'rc':..., 'paw':...} (either may be None) or None.
    """
    rows, averages = [], None
    for line in text.splitlines():
        if re.search(r'average', line, re.I):
            vals = [float(v) for v in AVG_NUM_RE.findall(line)]
            found = {
                'rc': next((v for v in vals if _in(v, config.RC_RANGE)), None),
                'paw': next((v for v in vals if _in(v, config.PAW_RANGE)), None),
            }
            if found['rc'] is not None or found['paw'] is not None:
                averages = found
            continue

        tokens = line.split()
        if not tokens:
            continue
        first = re.sub(r'[^0-9A-Za-z]', '', tokens[0])
        if not (
            len(first) in (12, 13)
            and first[-3:].isdigit()
            and re.fullmatch(r'\d{2}[A-Za-z0]?\d{7}|\d{2}[A-Za-z]\d{7}', first[:-3])
        ):
            continue

        rest = [re.sub(r'[^0-9.]', '', t) for t in tokens[1:]]
        rest = [t for t in rest if t and t != '.']
        nums = [float(t) for t in rest if re.fullmatch(r'\d+(\.\d+)?', t)]

        rc = next((v for v in nums if _in(v, config.RC_RANGE)), None)
        paw = next((v for v in nums if _in(v, config.PAW_RANGE)), None)
        notes = []
        if paw is None:
            paw, note = repair_paw(rest)
            if note:
                notes.append(note)
        if rc is None or paw is None:
            g_rc, g_paw = _split_glued(rest)
            if g_rc is not None:
                rc = rc if rc is not None else g_rc
                if paw is None:
                    paw = g_paw

        spool_no = first[-3:]
        rows.append({
            'spool_number': f'{lot}{spool_no}' if lot else first,
            'rc': rc,
            'paw': paw,
            'note': '; '.join(notes) or None,
        })
    return rows, averages


def check_averages(rows, averages):
    """True if computed RC/PAW means match the printed 'Averages:' line."""
    if not averages or not rows:
        return None
    checked = False
    for col in ('rc', 'paw'):
        if averages.get(col) is None:  # printed average was unreadable
            continue
        vals = [r[col] for r in rows if r[col] is not None]
        if not vals or abs(sum(vals) / len(vals) - averages[col]) > config.AVG_TOLERANCE:
            return False
        checked = True
    return True if checked else None
