"""Entry point for the RR material cert OCR extraction pipeline."""

import argparse
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import pandas as pd
from shared_config.sqlserver import PROD_SERVER, PYRO_DATABASE
from shared_utils.sqlserver import get_engine, replace_table

from . import config
from .pipeline import process_file


def run(pdf_path, sharepoint_url):
    """OCR every PDF under pdf_path. Always processes all files; the SQL table is
    replaced on each run, so there is no processed-file tracking."""
    root = Path(pdf_path)
    all_pdfs = [
        pdf for pdf in sorted(root.rglob('*')) if pdf.suffix.lower() == '.pdf'
    ]
    if not all_pdfs:
        print(f'No PDFs found in {pdf_path}')
        return None

    print(f'Found {len(all_pdfs)} PDF file(s) requiring processing...')

    results = []
    with ThreadPoolExecutor(max_workers=config.MAX_WORKERS_PDF) as executor:
        futures = {
            executor.submit(process_file, pdf, pdf_path, sharepoint_url): pdf
            for pdf in all_pdfs
        }
        for future in futures:
            try:
                df = future.result()
            except Exception as e:
                print(f'    FAILED {futures[future].name}: {e}')
                continue
            if not df.empty:
                results.append(df)

    df_all = pd.concat(results, ignore_index=True) if results else pd.DataFrame()

    print(
        f'\n{"=" * 64}\nTOTAL: {len(df_all)} records from {len(all_pdfs)} PDF(s)\n{"=" * 64}'
    )

    if not df_all.empty:
        df_all = df_all.sort_values(['lot_number', 'spool_number']).reset_index(drop=True)
        df_all['mfg_date'] = pd.to_datetime(df_all['mfg_date']).dt.normalize()

    return df_all


def main():
    parser = argparse.ArgumentParser(
        description='OCR RR (MSRR4040) material cert PDFs and load results into SQL Server.'
    )
    parser.add_argument(
        '--test', action='store_true', help='Use test PDFs instead of production PDFs.'
    )
    args = parser.parse_args()

    pdf_path = config.get_pdf_path(test=args.test)
    prod_engine = get_engine(PROD_SERVER, PYRO_DATABASE)

    df_all = run(pdf_path, config.SHAREPOINT_URL)

    if df_all is None or df_all.empty:
        print('No data extracted: skipping DB write')
    else:
        replace_table(df_all, table_name=config.TABLE_NAME, engine_name=prod_engine)


if __name__ == '__main__':
    main()
