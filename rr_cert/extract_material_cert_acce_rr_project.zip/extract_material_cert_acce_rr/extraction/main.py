"""Entry point for the RR material cert OCR extraction pipeline."""

import argparse
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import pandas as pd

from . import config
from .pipeline import get_processed_files, process_file

# Fixed columns first, then tg_*/tack_* in numeric order, then bookkeeping.
LEADING_COLUMNS = ['part_number', 'lot_number', 'mfg_date', 'spool_number', 'rc', 'paw']


def _order_columns(df):
    def numbered(prefix):
        cols = [c for c in df.columns if c.startswith(f'{prefix}_') and c[len(prefix) + 1:].isdigit()]
        return sorted(cols, key=lambda c: int(c.rsplit('_', 1)[1]))

    ordered = (
        LEADING_COLUMNS
        + numbered('tg') + ['tg_avg']
        + numbered('tack') + ['tack_avg']
        + ['needs_review', 'notes', 'pdf_path', 'pdf_url']
    )
    return df[[c for c in ordered if c in df.columns]]


def run(pdf_path, sharepoint_url, output_path, rerun_all):
    root = Path(pdf_path)
    processed_pdfs = get_processed_files(output_path) if not rerun_all else set()
    print(f'Files already in output: {len(processed_pdfs)}')

    all_pdfs = [
        pdf
        for pdf in sorted(root.rglob('*'))
        if pdf.suffix.lower() == '.pdf' and str(pdf.resolve()) not in processed_pdfs
    ]
    if not all_pdfs:
        print('No new PDFs for process.')
        return None

    print(f'Found {len(all_pdfs)} new PDF file(s) requiring processing...')

    results = []
    with ThreadPoolExecutor(max_workers=config.MAX_WORKERS_PDF) as executor:
        futures = {
            executor.submit(process_file, pdf, pdf_path, sharepoint_url): pdf
            for pdf in all_pdfs
        }
        for future in futures:
            try:
                df = future.result()
            except Exception as e:
                print(f'    FAILED {futures[future].name}: {e}')
                continue
            if not df.empty:
                results.append(df)

    df_all = pd.concat(results, ignore_index=True) if results else pd.DataFrame()

    print(
        f'\n{"=" * 64}\nTOTAL: {len(df_all)} records from {len(all_pdfs)} PDF(s)\n{"=" * 64}'
    )

    if not df_all.empty:
        df_all = df_all.sort_values(['lot_number', 'spool_number']).reset_index(drop=True)
        df_all['mfg_date'] = pd.to_datetime(df_all['mfg_date']).dt.normalize()
        df_all = _order_columns(df_all)

    return df_all


def write_output(df_all, output_path, rerun_all):
    """Write the workbook: replace on --rerun-all, otherwise append to what is there."""
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    if not rerun_all and Path(output_path).exists():
        existing = pd.read_excel(output_path)
        df_all = pd.concat([existing, df_all], ignore_index=True)
        df_all = df_all.sort_values(['lot_number', 'spool_number']).reset_index(drop=True)
        df_all = _order_columns(df_all)
    df_all.to_excel(output_path, index=False)
    print(f'Wrote {len(df_all)} rows to {output_path}')


def main():
    parser = argparse.ArgumentParser(
        description='OCR RR (MSRR4040) material cert PDFs and write results to Excel.'
    )
    parser.add_argument(
        '--test', action='store_true', help='Use test PDFs instead of production PDFs.'
    )
    parser.add_argument(
        '--rerun-all',
        action='store_true',
        help='Re-run all PDFs instead of only new ones.',
    )
    args = parser.parse_args()

    pdf_path = config.get_pdf_path(test=args.test)
    df_all = run(pdf_path, config.SHAREPOINT_URL, config.OUTPUT_PATH, args.rerun_all)

    if df_all is None or df_all.empty:
        print('No new files to analyze: skipping write')
    else:
        write_output(df_all, config.OUTPUT_PATH, args.rerun_all)


if __name__ == '__main__':
    main()
