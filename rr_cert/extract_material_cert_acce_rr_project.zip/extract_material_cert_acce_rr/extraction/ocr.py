"""OCR helpers and page classification for the RR material cert pipeline."""

from concurrent.futures import ThreadPoolExecutor

import pypdf
import pytesseract
from pdf2image import convert_from_path, pdfinfo_from_path

from . import config
from .parsing import classify_page_text

pytesseract.pytesseract.tesseract_cmd = config.TESSERACT_PATH


def _ocr_page(file, page_num, dpi, config_str=config.OCR_CONFIG):
    """Render one 1-indexed page to an image and OCR it. Returns (page_num, text)."""
    imgs = convert_from_path(
        file,
        dpi=dpi,
        poppler_path=config.POPPLER_PATH,
        first_page=page_num,
        last_page=page_num,
    )
    if not imgs:
        return page_num, ''
    return page_num, pytesseract.image_to_string(imgs[0], config=config_str)


def _ocr_many(file, page_numbers, dpi, config_str=config.OCR_CONFIG):
    """OCR a set of pages in parallel. Returns {page_num: text}."""
    page_numbers = sorted(set(page_numbers))
    if not page_numbers:
        return {}
    with ThreadPoolExecutor(max_workers=config.MAX_WORKERS_PAGE) as ex:
        return dict(ex.map(lambda p: _ocr_page(file, p, dpi, config_str), page_numbers))


def _text_layer(file):
    """Return {page_num: text} from the PDF text layer ('' for scanned pages)."""
    try:
        reader = pypdf.PdfReader(file)
        texts = {}
        for pn, page in enumerate(reader.pages, 1):
            text = page.extract_text() or ''
            texts[pn] = text if len(text.strip()) >= config.MIN_TEXT_CHARS else ''
        return texts
    except Exception as e:
        print(f'    pypdf could not open file: {e}; falling back to OCR scan.')
        return {}


def read_relevant_pages(file, dpi_value=config.LOW_DPI):
    """
    Two-pass read of one cert PDF.

    Pass 1: classify every page, from the text layer where there is one and from a
    low-DPI OCR otherwise (certs are often a mix of both).
    Pass 2: re-OCR only the relevant scanned pages at HIGH_DPI.

    Returns {page_num: (kinds, text)} for relevant pages only.
    """
    n_pages = pdfinfo_from_path(file, poppler_path=config.POPPLER_PATH)['Pages']
    layer = _text_layer(file)

    scan_pages = [p for p in range(1, n_pages + 1) if not layer.get(p)]
    low = _ocr_many(file, scan_pages, dpi_value)

    texts = {p: layer.get(p) or low.get(p, '') for p in range(1, n_pages + 1)}
    kinds = {p: classify_page_text(t) for p, t in texts.items()}
    relevant = {p: k for p, k in kinds.items() if k}

    rescan = [p for p in relevant if not layer.get(p)]
    high = _ocr_many(file, rescan, config.HIGH_DPI)

    return {p: (relevant[p], high.get(p) or texts[p]) for p in relevant}
