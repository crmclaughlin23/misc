# extract_material_cert_acce_rr

Extracts lot, spool and test data from RR (MSRR4040-VAFR, F3C 433/M65) material certification PDFs via OCR and loads one row per spool into SQL Server.

## Overview

Cert PDFs are a mix of text-layer pages (Matrix Testing Laboratory "Certificate of Analysis Report") and scanned pages (Hexcel cover sheet, "In Process Control / Lot Averages Report"). Each page is classified from its text layer where it has one, otherwise from a low-DPI Tesseract scan; only the relevant scanned pages are re-OCR'd at high DPI.

A single PDF can hold more than one lot, so every page is assigned to a lot (from its header) and rows are built per lot.

Fields extracted:

- **Cover sheet** — Part Number, Lot Number, Date of Manufacture
- **Spool table** — Spool Number, RC, PAW (parsed by value range, not column position; common OCR digit errors are repaired and noted)
- **Tg by DMA** — one value per panel (`tg_1`, `tg_2`, ...) and their mean (`tg_avg`)
- **ASTM D8336 Nottingham Tack** — printed per-panel tack force average, lbf (`tack_1`, `tack_2`, ...) and their mean (`tack_avg`). Only certs from 2026 onward carry it; older certs leave it blank.

Tg and tack are tested per panel, not per spool, so every spool row of a lot repeats that lot's values.

## Outputs

`material_cert_acce_rr` table — PROD_SERVER / PYRO_DATABASE — one row per spool: `part_number, lot_number, mfg_date, spool_number, rc, paw, tg_*, tg_avg, tack_*, tack_avg, needs_review, notes, pdf_path` (`pdf_url` too if `SHAREPOINT_URL` is set). The table is replaced on every run, so all PDFs are always reprocessed.

`needs_review` is True when a PAW was repaired, RC/PAW could not be read, the lot's computed RC/PAW means disagree with the printed `Averages:` line, or a lot has no spool table (a lot with only a Tg/tack report still gets one row).

## Usage

```powershell
uv run main.py
```

Standalone: `uv run python -m extraction.main`

Requires Poppler and Tesseract OCR installed locally; paths are set in `extraction/config.py` (`POPPLER_PATH` / `TESSERACT_PATH` env vars override them).

Put PDFs in `data/` (subfolders are fine).

## Status

Parsers were built and checked against the 10 sample PDFs in `data/` (11 lots, 197 spool rows).
