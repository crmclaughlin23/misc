# Cleaning and transforming data

import numpy as np
import pandas as pd

def clean_data(df):
    df['datafile'] = df['datafile'].str.replace('.DAT', '', regex=False)
    df['recipe'] = df['recipe'].str.split('\\').str[-1]
    df['date'] = pd.to_datetime(df['date'])
    df.replace([np.inf, -np.inf], np.nan, inplace=True)
    df.dropna(how='any', inplace=True)
    return df
