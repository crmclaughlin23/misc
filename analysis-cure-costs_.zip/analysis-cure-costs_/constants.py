# Project-specific constants

N2_MOLAR_MASS = 28.0134
N2_DENSITY = 1.251

# Van der Waal Equation
R = 0.08206 # L * atm / mol * K
A = 1.352 # L^2 * atm / mol^2
B = 0.0387 # L / mol

# Conversion factors
FT3_TO_L = 28.3168
PSI_TO_ATM = 14.7
