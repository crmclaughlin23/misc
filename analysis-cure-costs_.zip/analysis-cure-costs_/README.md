# analysis-cure-costs

Calculates per-run and per-segment electricity, gas, and nitrogen costs for cures,
reading from `EquipUsage_Runs` and writing `EquipEfficiency_CostPerRun` /
`EquipEfficiency_CostPerRunSeg`.

## Structure

Flattened from a `src/`-layout installable package (`package = true`, `cure-costs`
console script) to match the flat style used elsewhere in this repo. Nothing outside
this project imported `analysis_cure_costs` as a dependency, and the console script
wasn't part of the actual run workflow (`uv run main.py` via a trigger), so nothing
was lost by dropping it.

```
main.py              # entry point: uv run main.py
pyproject.toml
config.py            # rates, DB list, paths
constants.py         # physics constants (Van der Waals, N2, conversions)
pipeline.py          # main extraction + cost calculation pipeline
cost_calculations.py # NOT called by pipeline.py -- see "Open items"
utils/
  transform_data.py
  van_der_waals_eq.py
references/
  EquipInputs.xlsx
notebooks/           # originals, kept for reference
```

## Fixes applied

- **`_fle` fields removed** (`kwh_fle`, `gas_fle`, `n2_fle`) from calculations,
  aggregations, and both output tables. Unused.
- **`gas_used` aggregation corrected.** Was `mean` at both the segment and cure
  level; because gas is nonzero on exactly one input row per segment, that divided
  the true value by (rows x segments) -- 65x understated on a 13-input machine with
  5 segments. Now `max` at segment level and `sum` at cure level. `gas_cost` was
  already correct (`sum`), so the two columns previously contradicted each other;
  `gas_used * GAS_RATE` now equals `gas_cost`.
- **`kwh_used` / `gas_used` reset per input row.** A `Gas` row never assigns
  `kwh_used`, so it silently reused the previous row's value. Since `kwh_used`
  aggregates with `sum`, the last electric input (`VACPUMPON`) was double-counted
  on every segment of AC6 and CAC1-CAC5.
- **Analog rows with a missing `analog_divisor` now warn and skip.** Previously
  `row.get('analog_divisor', 1)` returned `NaN` (the default only fires on a
  missing *label*, not a NaN *value*), which propagated to `0 kWh` silently. This
  had zeroed out 48-70% of several machines' capacity without any error.
- **DB engine and `EquipUsage_Runs` read moved inside `run_pipeline()`.** They ran
  at import time, so merely importing the module opened a connection and pulled the
  whole table -- making it unimportable and untestable without DB access.
- **Vessel volume hoisted out of the pressure branch.** `V` was assigned only inside
  `shape == 'cylinder'` / `elif 'box'`, nested inside the pressure check, but read
  unconditionally. Now computed once per piece of equipment via
  `compute_vessel_volume()`, which returns `None` for an unrecognized shape (the
  machine is then skipped with a message). Latent today, but would have silently
  carried the previous machine's volume the moment a non-pressurized oven was added
  to `DATABASE_NAMES`.
- **Pressure spike filter no longer shrinks the electricity/gas row set.** The
  filter exists for the N2 integration; it rebound `df_group`, so the removed
  minutes also vanished from the kWh and gas sums. Now applied to a separate
  `df_n2` frame.
- **Row drops narrowed and logged.** `dropna(how='any')` spanned ~40 columns, so a
  single NULL `Operator` or `Program` silently deleted an entire cure. Now scoped to
  `COST_COLUMNS` via `drop_incomplete_rows()`, which prints how many rows it drops.
- **Per-row `round(x, 2)` removed from cost fields.** Rounding happened before
  aggregation, so error accumulated across 13 rows x n segments. Output is still
  rounded to 2 dp by the final `.round(2)`.
- **`equip_power` reduced to a scalar** with an `.empty` guard, matching `pressure`.
  As a bare Series it raised `ValueError: truth value of a Series is ambiguous`
  whenever a machine matched zero or multiple reference rows.
- **Cosmetic:** `(do data found)` -> `(no data found)`; `/nBeginning` -> newline;
  `print(rf'...')` -> `f'...'` (the `r` prefix was printing a literal `\n`); the
  nested `DATABASE_NAMES` loop replaced with a membership test; hardcoded `14.7`
  replaced with `constants.PSI_TO_ATM`; `ref_df['equipment'].str.upper()` hoisted
  out of the loop. Volume now uses `math.pi` rather than the literal `3.1416`
  (changes `volume_ft3` by ~0.002%).

## Deliberately NOT changed

- **The unreachable `elif` in `additional_columns`.** Any `pressure == 'yes'` is
  caught by the first branch, so the pressure+gas branch never fires. This is
  harmless and in fact protective: `BURNERGASFLOW` already arrives via
  `columns_to_pull`, so adding `rd.BURNERGASFLOW` here would put the column in the
  SELECT twice. `df_seg[input_name]` would then return a DataFrame instead of a
  Series and `pd.to_numeric` would raise `TypeError` -- outside the `try/except`,
  so a hard crash. For AC1/AC10/AC12 (`equip_power='gas'` but no Gas input row) it
  would also fail the query outright and silently skip those machines.
- **Segment-level `kwh_cost_per_hr` / `gas_cost_per_hr` still divide by the full-run
  `duration`**, not `seg_duration`. Intentional: the figure represents that
  segment's share of a run-hour.

## Open items

1. **`cost_calculations.py` is not called by `pipeline.py`.** `pipeline.py` has its
   own inline version of the same logic, and the two have diverged: the inline N2
   calculation integrates moles across the whole cure with a spike filter, while
   `cost_calculations.py` estimates from a single max-pressure reading; and
   `cost_calculations.py`'s cylinder volume formula multiplies the two terms that
   `pipeline.py` adds. Either delete it or refactor `pipeline.py` to call it,
   bringing the volume fix along.
2. **`AC16 / VFDFanSpeed`** was the last reference row typed Digital while carrying
   a divisor; now Analog. AC16 remains commented out of `config.DATABASE_NAMES`.

## Usage

```powershell
uv run main.py
```
